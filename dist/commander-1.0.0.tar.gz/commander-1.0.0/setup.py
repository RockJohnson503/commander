# encoding: utf-8

"""
File: setup.py
Author: Rock Johnson
"""
from setuptools import setup

setup()